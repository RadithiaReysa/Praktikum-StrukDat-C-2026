stok = [15, 50, 30, 25, 40]
#1. Tambahkan stok baru sebesar 100 ke akhir list.
stok.append(100)
print(stok)
#2. Sisipkan angka 75 di posisi indeks ke-2.
stok.insert(2,75)
print(stok)
stok.sort()
print(stok)





barang = ("B001", "Laptop Gaming", 15000000)
print(barang[2])

y = list(barang)
y[2] = 14000000
barang = tuple(y)
print(barang)

(kode,nama,harga) = barang
print(kode)
print(nama)
print(harga)


tim_frontend = {"HTML", "CSS", "JavaScript", "React"}
tim_backend = {"Python", "JavaScript", "SQL",
"NodeJS"}
tim3 = tim_frontend & tim_backend
print(tim3)

tim4 = tim_backend-tim_frontend
print(tim4)

tim5 = tim_frontend.union(tim_backend)
print(tim5)



nilai_siswa = {
"S01": {"nama": "Dina", "tugas": 80, "uts": 75,
"uas": 85},
"S02": {"nama": "Abdul Harris", "tugas": 90, "uts":
88, "uas": 92},
"S03": {"nama": "Sheila", "tugas": 70, "uts": 65,
"uas": 70}
}


